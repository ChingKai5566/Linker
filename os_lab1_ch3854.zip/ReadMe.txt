Need to switch compiler versions on linserv1 first
$ module load gcc-9.2